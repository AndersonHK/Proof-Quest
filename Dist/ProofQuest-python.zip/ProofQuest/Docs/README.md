# Documentation map

Each guide owns one part of the current application contract. Update that guide when the corresponding behavior changes.

- [User guide](User-Guide.md): practice, active exam time, dataset selection, playback, shortcuts, settings, and histories. Also displayed by the Help button.
- [Dataset format](Dataset-Format.md): schema, character offsets, generator instructions, and privacy boundaries.
- [Question curation](Question-Curation.md): answer anti-patterns, distractor review, and sampling audits.
- [Distribution editions](../Dist/README.md): Windows installer, portable ZIP, and Python-source ZIP.
- [Development](Development.md): source structure, building, ZIP packaging, and local installation/update.
- [Validation](Validation.md): evidence and limits for the current committed executable.

Start with the [root README](../README.md) to run the app or [AGENTS.md](../AGENTS.md) before editing it. Raw captures and intermediate reports belong in ignored `Out/`.
